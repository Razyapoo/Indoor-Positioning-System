# SCUT_HEAD_NEW > 2022-03-02 2:53pm
https://universe.roboflow.com/object-detection/scut_head_new

Provided by a Roboflow user
License: CC BY 4.0

