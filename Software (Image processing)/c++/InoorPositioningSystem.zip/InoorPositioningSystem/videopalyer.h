#ifndef VIDEOPALYER_H
#define VIDEOPALYER_H

#include <QObject>
#include <QWidget>
#include <QtMultimedia/QtMultimedia>
#include <QtWidgets>
#include <QtMultimediaWidgets/QtMultimediaWidgets>

class VideoPalyer
{
public:
    VideoPalyer();

private slots:


private:

};

#endif // VIDEOPALYER_H
