#include "chartlayout.h"

chartlayout::chartlayout() {}
