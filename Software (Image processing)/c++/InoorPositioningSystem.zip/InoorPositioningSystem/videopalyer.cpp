#include "videopalyer.h"

VideoPalyer::VideoPalyer()
{

}
